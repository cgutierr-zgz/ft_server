<?php
/* ARCHIVO DE CONFIGURACIÓN DE WORDPRESS*/

/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '0D3gru+,6w=;s^l= #J:M+Mab6oL/NA+ugJ:#[h9[b#[Oz>Xz[aJq +kQZwbr6lo' );
define( 'SECURE_AUTH_KEY',  'UlTVJIM|.olwIDtt1}ne+<*a8j<WEj3gY+2k;{8fS!>EgT39xfi2mI_tJa|PM(0$' );
define( 'LOGGED_IN_KEY',    'GwbL48CuqWV[-zEDRoVy?CP12ZQg45VE_b.HBA, ` ]=5t%T;FamV) #Qbs?^lrv' );
define( 'NONCE_KEY',        '.06zA#IEhk^G6b[D8{j1UUzHbCOw6Kh~6,0tQWXt<C$d}N-XP^wZ8W*42qQ7zDcp' );
define( 'AUTH_SALT',        'dq9%kA)!Nepv;5Bu76a?cN}H+2_:{YyQIc}@v,H:qpBCCNeE>>n<4Hg|1F/pM:2s' );
define( 'SECURE_AUTH_SALT', 'a)[ahgE9T7Ug}Mz%*RMw3-[14?KhAP,vrLn[+t61s<+{wz2(q`ZSr=Z.2doZ,7Jf' );
define( 'LOGGED_IN_SALT',   '[F#Lxf:9b,lIIAv+o[[K`PwnrAd7,iPEafq9JVksdnXIj|%f,apen~qRt~7pDb2c' );
define( 'NONCE_SALT',       '^e|y`V)#c-u{BHL[>+-<(<I1*yiis>l-Z@*`I8OG?Jt~,H@Yi9.c`*BreEueFDa+' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';