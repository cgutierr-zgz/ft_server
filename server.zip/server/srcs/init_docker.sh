#!/bin/bash

#Pido por pantalla que me diga qué valor quiere de autoindex
echo "Elige on u off para autoindex"
read autoindex
if [ "$autoindex" == "on" ]; then
	sed -i 's/autoindex off;/autoindex on;/g' /etc/nginx/sites-enabled/wordpress.conf
	sed -i 's/autoindex off;/autoindex on;/g' /etc/nginx/sites-enabled/phpmyAdmin.conf
elif [ "$autoindex" == "off" ]; then
	sed -i 's/autoindex on;/autoindex off;/g' /etc/nginx/sites-enabled/wordpress.conf
	sed -i 's/autoindex on;/autoindex off;/g' /etc/nginx/sites-enabled/phpmyAdmin.conf
else
	echo "No has metido valor válido" && exit
fi

#Voy al directorio donde quiero guardar:
#   - phpMyAdmin (interfaz gráfica de mySQL)
#   - wordpress
cd /var/www/

#Descargo phpMyAdmin y wordpress
wget https://files.phpmyadmin.net/phpMyAdmin/5.0.2/phpMyAdmin-5.0.2-all-languages.zip
wget https://es.wordpress.org/latest-es_ES.zip

#Descomprimo
unzip latest-es_ES.zip && unzip phpMyAdmin-5.0.2-all-languages.zip

#Borro los .zip para limpiar el directorio
rm -rf latest-es_ES.zip && rm -rf phpMyAdmin-5.0.2-all-languages.zip

#Copio el archivo de configuración de wordpress a la carpeta de wordpress
#lo tengo que hacer ahora porque antes no existía la carpeta wordpress,
#se crea una vez que descomprimo la descarga de wordpress, antes no existía
mv wp-config.php wordpress/

#Igual que antes, pero para phpMyAdmin
mv phpMyAdmin-5.0.2-all-languages/ phpMyAdmin
mv config.inc.php phpMyAdmin/
#Dar permisos al usuario de nginx (está en /etc/nginx/nginx.conf), que es
#www-data, para que pueda ver las carpetas de la web a la que se conecte
#Lo hago de forma recursiva, para esa carpeta (var/www) y todas las que 
#están por debajo de ella
#chwon cambio grupo y usuario al que pertenece
#chmod cambia los permisos de acceso
chown -R www-data .
chmod -R 755 .

#Inicio mySQL
service mysql start

#Creo la base de datos y configuro los permisos para root
echo "CREATE DATABASE wordpress;" | mysql -u root --skip-password
echo "GRANT ALL PRIVILEGES ON wordpress.* TO 'root'@'localhost' WITH GRANT OPTION;" | mysql -u root --skip-password
#Configura la contraseña, básicamente sin contraseña
echo "update mysql.user set plugin='mysql_native_password' where user='root';" | mysql -u root --skip-password
#Guardo los cambios de los privilegios
echo "FLUSH PRIVILEGES;" | mysql -u root --skip-password

#Inicio php-fpm, que es el servicio encargado de interpretar el código de PHP,
#y compilarlo para que se convierta en una página web, y lo pueda leer nginx
service php7.3-fpm start

#Creo carpeta para almacenar los certificados ssl
mkdir cert
cd cert/
mkdir wordpress
mkdir phpmyadmin
#Configuro certificado ssl
openssl req -x509 -sha256 -nodes -newkey rsa:4096 -keyout wordpress/key.pem -out wordpress/cert.pem -days 365 -subj "/C=ES/ST=Madrid/L=Madrid/O=42/OU=Learner/CN=localhost"
openssl req -x509 -sha256 -nodes -newkey rsa:4096 -keyout phpmyadmin/key.pem -out phpmyadmin/cert.pem -days 365 -subj "/C=ES/ST=Madrid/L=Madrid/O=42/OU=Learner/CN=127.0.0.1"

#Inicio nginx
nginx

#Abro terminal
bash