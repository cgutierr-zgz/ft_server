# README

Lo primero, puede costarnos iniciar Docker en nuestro MAC.
- Puede ser por falta de espacio del equipo, y hay que borrar cosas (Solución: En el menú go del Finder presiona alt y aparece library, y ahí borrar)
- Si aun así después de hacer esto no inicia, ejecutar init_docker.sh que está en https://github.com/alexandregv/42toolbox

¿Qué tengo que instalar?
- nginx
- php-fpm (traduce el código de wordpress a algo que puede ver el usuario)
- php-mysql (extensión de php, para conectar php a MySQL)
- mariadb-server (la base de datos de MySQL)
- phpMyAdmin
- Wordpress

¿Qué tengo que configurar?
- nginx. Tengo que decirle dónde están:
    + wordpress (no es wordpress en sí, es el archivo de configuración de wordpress para nginx)
    + phpmyadmin (no es phpmyadmin en sí, es el archivo de configuración de phpmyadmin para nginx)
- Cuando hago cambios, reinicio nginx, para que los coja: nginx -s reload

Estos son los pasos que he seguido para crear mi proyecto

1. Creo mi Dockerfile
- Le digo la imagen-->  FROM debian:buster
- Le digo qué tiene que hacer:
    1. Actualizar paquetes (para asegurarme que tengo las últimas versiones a la hora de descargar)--> RUN apt update
    2. Instalar nginx --> **RUN -y install nginx** (la y es para que no me pregunte, ya que dentro del dockerfile no hay interacción humana, así que directamente le digo yes para cuando me pregunte)
    3. Abrir terminal: CMD bash

--------------- Todo esto es la configuración que tengo que hacer dentro del dockerfile-------------------------------
--------------- la fui haciendo por terminal paso a paso para ver que iba funcionando---------------------------------
--------------- He combinado mi Dockerfile con un archivo ejecutable y entre los dos van haciendo todo----------------
2. Quiero ejecutar nginx pero primero hay que configurarlo. Vamos a cogerlo por defecto

Ahora estamos dentro de la terminal y por eso aparece #.
Cuando aparece # tenemos permisos de administrador
Si aparece $ somos usuario normal

3. Ejecuto nginx, pongo en la terminal --> nginx

4. Para saber si está corriendo, abro navegador. Hay 3 formas:
    + ip del ordenador en esta red (System preferences -> Network)
    + ip de mi localhost 127.0.0.1
    + Poner localhost
Con cualquiera de estas veo nginx porque he puesto que esté por defecto y siempre me muestra eso, hasta que lo cambie (cualquier página que apunte aquí me lleva a nginx)

5. Descargar wordpress. Opciones:
    + Descargarlo en el Dockerfile
    + Configurar la descarga desde un archivo ejecutable

Con el docker iniciado voy a la terminal. Veo las carpetas que hay en /var/www (tiene que ir ahí porque es el sitio donde suelen poner las páginas web)

6. Cambiar la configuración para hacerlo todo (descargar) dentro de var/www. Crear fichero

7. Iniciar nginx

--------------- Todo lo anterior tiene que estar creado en el dockerfile y en mi archivo .sh-------------------------
--------------- A partir de ahí es donde construyo mi imagen y el contenedor (ver siguientes pasos)------------------
 
8. Crear imagen. Voy a la terminal y ejecuto el siguiente comando:
**-->docker build -t nombre .** -t nombra y etiqueta, es opcional. No olvidarse el punto al final; espacio y punto
Para construir una imagen necesitamos un Dockerfile; cuando ejecutamos este comando, el **.** que le paso como parámetro significa que coja el dockerfile de la carpeta en la que está

9. Correr el contenedor: coger la imagen, ponerla en el contenedor e iniciar ese contenedor, con el siguiente comando:
**-->docker run --name nombrecontenedor -it -p 80:80 -p 443:443 nombreimagen**
p 80:80 el primer puerto es el externo y el segundo el interno


# NOTAS
- nginx sirve contenido; coge algo y lo sirve a quien se lo pide
- wordpress y php es el contenido a servir
- En el archivo paso a paso está lo que he ido haciendo para crear tanto mi dockerfile como mi ejecutable; configuración, ficheros y todo lo necesario
- Certificado ssl: hay  mil formas de generarlo

# Información importante (vídeos, posts,... todo lo que he visto y me ha ayudado)
- Aprende docker en 14 minutos: https://www.youtube.com/watch?v=6idFknRIOp4&t=4s
- Lista de reproducción de Docker: https://www.youtube.com/watch?v=UZpyvK6UGFo&list=PLqRCtm0kbeHAep1hc7yW-EZQoAJqSTgD-
    + Introducción a docker
    + Primeros pasos en docker
    + Volúmenes y puertos en docker
- Lista de reproducción de nginx: https://www.youtube.com/watch?v=_LQv96MdtCk&list=PLqRCtm0kbeHD7A5f8Yft-5qFg-sgXvGzR
    + Instalando y configurando nginx
    + Configurando nginx: LEMP: pp + MySQL
    + Certbot (Pruebas con Wordpress)
- Guía de instalación de LEMP: https://www.digitalocean.com/community/tutorials/how-to-install-linux-nginx-mariadb-php-lemp-stack-on-debian-10
- Configurar un servidor HTTPS con Nginx: https://softwarecrafters.io/devops/configurar-servidor-https-nginx
- Entender autoindex: https://www.youtube.com/watch?v=Gh7LHvTgqr4&list=PLYAyQauAPx8kwPdi9v1d_FGdJ50_li_WE&index=30&t=0s
