# README
# En este documento está la lista de lo que debe contener mi dockerfile y mi archivo ejecutable. Hay cosas que las he puesto dentro del ejecutable directamente porque me resultaba más fácil acceder a los directorios desde allí que desde el dockerfile.
# De hecho, cuando intentaba ir al directorio **var/www/** desde el dockerfile no iba y no me descargaba las cosas donde yo quería, por eso lo hice desde el ejecutable, y al final es una combinación de los dos, ya que dentro del dockerfile lo último que hago es abrir terminal y ejecutar el archivo
# Para comprobar qué está en cada sitio y en qué orden, ver __Dockerfile__ y __init_docker.sh__

1. Actualizamos todos los paquetes que vamos a instalar
    **apt-get update**
    - Actualiza todo
    - apt-get funciona para ubuntu o debian
    (Update lista los paquetes de los repositorios y el upgrade instala las actualizaciones)

2. Instalar nginx
    **apt-get install nginx**
    - En ubuntu se inicia automáticamente, no hay que correr ningún comando para iniciar tu servidor
    - Ya tenemos nginx instalado y corriendo
    - Hay que configurarlo para que muestre nuestro sitio
        + Vamos al directorio donde están los archivos de configuración: cd/ect/nginx
        + Tenemos dos directorios que nos interesan:
            - **sites-available**: donde está la configuración de todo lo que tengas en tu servidor. Cada sitio está diferenciado por el virtual host, y puedes acceder a esos sitios por el dominio o subdominio
                + Por defecto ya tenemos el fichero _default_ configurado, lo copiamos para crear los nuestros sobre este (generalmente se le nombra como el nombre del dominio o subdominio, así se ve cuál es el archivo y a qué apunta cada uno):
                    - wordpress.conf (archivo de configuración de wordpress para nginx)
                    - phpMyadmin.conf (archivo de configuración de phpMyadmin para nginx)
                + Modificamos los ficheros:
                    - wordpress.conf:
                        Donde pone **listen 80 default server** (hay dos líneas), quitamos default server, ya que solo puede haber un default server
                        Donde pone server_name cambiamos el guión bajo por _localhost_ 
                        Donde pone root /var/www/html (es donde están los archivos de nuestro sitio) cambiamos html por _wordpress_
                        (lo que conseguimos con esto es que cuando pongamos en el navegador localhost, nos va a llevar a wordpress)
                    - phpMyadmin.conf:
                        Donde pone **listen 80 default server** (hay dos líneas), quitamos default server, ya que solo puede haber un default server
                        Donde pone server_name cambiamos el guión bajo por _127.0.0.1_
                        Donde pone root /var/www/html (es donde están los archivos de nuestro sitio) cambiamos html por _phpMyAdmin_
                        (aquí al final lo he cambiado y he dejado solo root /var/www/, para que así con el **autoindex on** me indexe/liste los ficheros del directorio y ver que el autoindex funciona)
                        (lo que conseguimos con esto es que cuando pongamos en el navegador 127.0.0.1, nos va a llevar a phMyAdmin)
            - **sites-enabled**: tenemos que pasar estos sitios de disponibles a activos, es decir, a este directorio. 
            Lo podemos hacer de dos maneras, copiándolos aquí directamente, o haciendo un enlace simbólico. 
            La diferencia está en que si los ponemos directamente cuando ya no los queramos hay que borrarlos, y de la otra manera, basta con desactivarlos. Si hacemos el enlace simbólico:
                + Los archivos están ya en sites-available
                + Vamos a sites-enabled y hacemos link simbólico (es como un puntero a un archivo que está en otro lugar)
                    ln -s ../sites-available/archivo .
    - Tras estos cambios tenemos que reiniciar nginx: **nginx -s reload**
    - Es muy importante que el sitio que estemos usando apunten a la ip de nuestro servidor, porque si no nunca vamos a visitar nuestro servidor
    - ¿index.html?

3. Instalar php-fpm, que es el servicio que se encarga de interpretar el código php y compilarlo para que se convierta en una página web que pueda leer nginx
    **apt-get install php-fpm**
¿Por qué? nginx no lee php, cuando lee un archivo .php no sabe que tiene que compilarlo y lo va a leer como texto plano; por eso instalamos el servicio php-fpm

4. Configurar nuestro virtual host para que use php
    - Para eso tenemos que modificar los archivos que usamos anteriormente: **wordpress.conf** y **phpMyadmin.conf**
    - En el archivo de configuración de nginx la sección de php viene comentada, hay que descomentarla:
        + Descomentamos las siguientes líneas:
            	location ~ \.php$ {
		            include snippets/fastcgi-php.conf;
                    fastcgi_pass unix:/run/php/php7.3-fpm.sock;
                }
        OJO!! Lo hacemos mediante sockets, no por puerto tcp porque por defecto ubuntu php no usa puerto tcp, no inicia ese servicio, por eso desconectamos esto y no donde aparece tcp, solo se puede usar una de las dos opciones
        + Denegamos el acceso a los archivos .htaccess. ¿Por qué? Son típicos de instalación con Apache y no están soportados con nginx Y además tienen información sensible a la que no queremos que se accdea.
        Para ello descomentamos las siguientes líneas:
                location ~ /\.ht {
		            deny all;
	            }
    - Hay que hacer esto en los dos archivos, OJO!! **wordpress.conf** y **phpMyadmin.conf**
    - Después de haber hecho estos cambios, podemos comprobar que la sintaxis está bien con el comando **nginx -t**
    - Reiniciamos servicios porque hemos tocado los archivos de configuración: **systemctl reload nginx**
    - Si queremos ver si funciona, crear archivo php. Miramos nuestro root (var/www) y vamos ahí, creamos el archivo info.php:
        <?php
        phpinfo();
        ?>
    Si vamos a la página y aparece un cuadro con información de php, es que php funciona

5. Instalamos MySQL
    **apt-get install mysql-server php-mysql** (php-mysql es el módulo de php para que se pueda conectar a mysql, para que  nos traiga todas las funciones que mysql necesita)
    - Cuando ya se ha instalado, se inicia nuestro servidor de mysql. Ejecutamos mysql, y estamos dentro
    - Para comprobarlo, ponemos **show databases** y nos aparecen las bases de datos por defecto (esto en la terminal)

6. ¿Cómo podemos proar que la integración de php con nginx y mysql funciona?
    - Nos descargamos phpMyAdmin (interfaz web para mysql hecha en php); copiamos la url de descarga
    - Vamos a nuestra ruta var/www/phpMyAdmin y ahí:
        **wget url**
        **apt-get install unzip url** (para descomprimir lo que nos hemos descargado)
        **unzip archivo**
    - En los archivos de configuración (wordpress.conf y phpMyadmin.conf) hay que incluir **index.php** a la lista, y el orden importa, hay que ponerlo justo tras index, para que lo busque el primero. De hecho pone que si usas php tienes que añadir index.php
    - Hay que reiniciar los servicios de nginx!!
    - Creamos usuario en phpmyAdmin y vemos que todo funciona y todos los componentes funcionan entre ellos

7. Wordpress: para instalarlo necesitamos tener php y mysql instalado, evidentemente también nginx)
    - Descargamos wordpress, copiando la url de descarga:
        **wget url**
        **unzip archivo**
    - Llevamos el contenido  dentro del root de mi página web
        **mv wordpress/* /var/www/wordpress
    - Cambiamos los permisos de escritura para el usuario de nginx (www-data)
        **chown -R www-data:www-data /var/www/midirectorio** -> basta poner **chown -R www-data .**
    donde -R indica que es recursivo, todo el contenido, y les estoy diciento que para ese directorio, usuario y grupo son www-data
    - Damos permisos:
        **chmod -R 755 .**
            (En los vídeos que he visto, sugiere esta forma de dar permisos:
            **find /var/www/pablo -type d -exec chmod 0755 {} \;**
            **find /var/www/pablo -type f -exec chmod 0644 {} \;**
            esto lo que hace es buscar todos los directorios/ficheros y damos permisos 0755/0644)
    - Después de instalarlo, hay que configurarlo. Cogemos el archivo de muestra, y lo renombramos: **wp-config.php**
    Modificamos:
        + DB_NAME: wordpress
        + DB_USER: root
        + DB_PASSWORD: nada
        + DB_HOST: localhost
    - Tenemos que crear una base de datos para wordpress, crear usuario y dar permisos:
        CREATE DATABASE wordpress;
        CREATE USER 'wordpressuser'@'localhost' IDENTIFIED BY 'new_password_here';
        GRANT ALL ON wordpress.* TO 'wordpressuser'@'localhost' IDENTIFIED BY 'user_password_here' WITH GRANT OPTION;
        FLUSH PRIVILEGES;
    - Una vez hecho esto vamos a nuestro sitio web, y ya está wordpress listo. Rellenamos los datos que nos piden y nos crea la estructura. Iniciamos sesión y estamos dentro de wordpress

8. Tengo que poner **autoindex on** para que me funcione, listando los index. ¿Dónde? Lo ponemos en wordpress.conf y phpMyadmin.conf, justo después de **server_name localhost**, dentro del location que va después

9. Protocolo ssl
    - Creo directorio para los certificados
        mkdir cert
        cd cert/
        mkdir wordpress
        mkdir phpmyadmin
    - Configurar certificado ssl
        openssl req -x509 -sha256 -nodes -newkey rsa:4096 -keyout wordpress/key.pem -out wordpress/cert.pem -days 365 -subj "/C=ES/ST=Madrid/L=Madrid/O=42/OU=Learner/CN=localhost"
        openssl req -x509 -sha256 -nodes -newkey rsa:4096 -keyout phpmyadmin/key.pem -out phpmyadmin/cert.pem -days 365 -subj "/C=ES/ST=Madrid/L=Madrid/O=42/OU=Learner/CN=127.0.0.1"
    - Configurar nginx (en los archivos wordpress.conf y phpMyadmin.conf)
        + Descomento las siguientes líneas:
            listen 443 ssl;
	        listen [::]:443 ssl;
        + Añado al final lo siguiente:
            	ssl_certificate     /var/www/cert/wordpress/cert.pem;
                ssl_certificate_key /var/www/cert/wordpress/key.pem;
    - Hay que reiniciar nginx tras los cambios en los archivos de configuración

10. Autoindex
- Al principio de mi ejecutable, para que lo pregunte directamente antes de descargar nada, le pido que me diga si quiere que se haga con autoindex on o autoindex off, de manera que:
    + Si elige on  --> cambia el autoindex de off a on (si estaba a on no hace nada, lo deja como está)
    + Si elige off --> cambia el autoindex de on a off (si estaba a off no hace nada, lo deja como está)
    + Si mete algo que no es ni on ni off --> te dice que no has metido un valor válido y sale
- Cómo hago que haga esto:

echo "Elige on u off para autoindex"
read autoindex
if [ "$autoindex" == "on" ]; then
	sed -i 's/autoindex off;/autoindex on;/g' /etc/nginx/sites-enabled/wordpress.conf
	sed -i 's/autoindex off;/autoindex on;/g' /etc/nginx/sites-enabled/phpmyAdmin.conf
elif [ "$autoindex" == "off" ]; then
	sed -i 's/autoindex on;/autoindex off;/g' /etc/nginx/sites-enabled/wordpress.conf
	sed -i 's/autoindex on;/autoindex off;/g' /etc/nginx/sites-enabled/phpmyAdmin.conf
else
	echo "No has metido valor válido" && exit
fi

- Tengo que cambiarlo en los dos ficheros donde tengo autoindex, que son los ficheros de wordpress y phpMyAdmin para nginx. Lo hago con la instrucción sed, que lo que hace es:
    + **-i** redirige al mismo fichero. Guarda los cambios en el mismo fichero en el que está. Se usa para modificar el fichero sin necesidad de guardar el output resultante en un archivo temporal, y entonces reemplazar el archivo original.
    Es decir, en vez de poner __sed 's/a/b/g' file > file.tmp; mv file.tmp>file__ lo hacemos todo con esta instrucción: __sed -i 's/a/b/g' file__
    + **s** sustituye la primera cadena por la segunda
    + **g** sustituye todas las cadenas que encuentre en el fichero entero, no solo una vez

# --------------------------------
# Para comprobar que todo funciona
# --------------------------------
- Estos son  los pasos que tenemos que seguir una vez construida imagen y contenedor, es decir, tras ejecutar esto:
    **-->docker build -t nombre .**
    **-->docker run --name nombrecontenedor -it -p 80:80 -p 443:443 nombreimagen**
- Pasos a seguir para comprobar que todo funciona bien
    - Elegir autoindex on/off/otra cosa
        + on: 127.0.0.1 funciona, se ve la lista, el índide. A wordpress (localhost) no le afecta porque en su configuración tengo puesta toda su ruta
        + off: 127.0.0.1 dice que no se puede acceder porque no hay autoindex
        + cualquier otra cosa: te dice que no es el valor esperado y sale directamente
    - Pongo en el navegador localhost:
        + Me dice que la conexión no es privada (mi certificado lo he firmado yo misma en realidad...) --> Advanced --> Proceed to localhost (unsafe)
        + Me lleva a Wordpress. Rellenar título (whatever...), nombre (root), contraseña (root, y confirmar el uso de cpw débil),correo (inventado: hola@hola.com) --> Instalar --> Acceder
        + Entrar con usuario y pw:  nos aparece la página inicial
        + Vamos arriba a la derecha y vemos una casita, clicamos y nos lleva a visitar el sitio. Es como un post que pone ¡Hola, mundo!
    - Pongo en el navegador 127.0.0.1:
        + Me dice que la conexión no es privada (mi certificado lo he firmado yo misma en realidad...) --> Advanced --> Proceed to localhost (unsafe)
        + Si autoindex on:
            - Me aparece un índice con el listado de ficheros que hay en esa ruta, selecciono --> phpMyAdmin
        + Si autoindex off:
            - Me dice que no puede acceder, no hay index
        + Me logo solo con usuario (root) y aparece phpMyAdmin
        + En el menú de la izquierda desliego wordpress-->wp_posts (ahí clico encima) y me aparecen los posts existentes, entre ellos ¡Hola, mundo!
            - Edito este post y cambio lo que hay por lo que yo quiera, voy abajo del todo y doy a Go
            - Vuelo a wordpress y actualizo. Ha de desaparecer ¡Hola, mundo! y aparecer lo que yo he puesto