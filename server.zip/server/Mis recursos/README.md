# README

ft_server

# REQUERIMIENTOS
- Nuestro contenedor debe configurar/descargar/instalar tods los servicios cuando ejecutemos el comando **docker build**. NO debemos configurar ningún servicio o cambiar ningún archivo tras usar **docker run** porque reduce la funcionalidad de docker

- Esto significa que **wordpress** debe instalarse durante **docker build** y no por medio de wp-setup.php tras correr el contenedor

- **Wordpress** debe funcionar en su totalidad, hay que asegurarse de verificar correos/carga de archivos/cargar e instalar temas/crear posts/instalar módulos. Verificar también si tenemos la extensión correcta de **php** instalada

- **PHPMyAdmin** debe funcionar en su totalidad, hay que asegurarse de poder crear una base de datos, descargar una base de datos, crear y borrar usuarios, actualizar tablas...

- Asegurarse de tener los permisos correctos para tood el sistema. Es muy importante, ya que es lo que garantizará que docker no sea víctima de ejecución remota de código

- Puedes crear tus propias imágenes o usar una ya creada y publicada. Para construir tu imagen, creas un Dockerfile con una sintaxis simple para definir los pasos necesarios para crear una imagen y después lo ejecutas. Cada instrucción en un Dockerfile crea una ventana en la imagen. Cuando cambiamos el Dockerfile y reconstruimos la imagen, sólo se reconstruyen las ventanas que han cambiado. Esto es parte de lo que hace que las imágenes sean tan ligeras, pequeñas y rápidas comparadas con otras tecnologías de virtualización

- Un contenedor es una instancia ejecutable de una imagen. Puedes crear, iniciar, parar, mover o borrar un contenedor usando Docker API o CI. Puedes conectar un contenedor a una o más redes, adjuntar almacenamiento o incluso crear una nueva imagen basada en su estado actual

Información que he ido encontrando para saber qué es docker

- Docker proporciona la habilidad de empaquetar y ejecutar una aplicación en un entorno asilado llamado contenedor

# CONTENEDORES
 - En lugar de virtualizar la máquina entera, virtualizamos el sistema operativo (s.o.)
- Cada contenedor no tiene una copia completa, tiene una fracción. No tienes una copia de cada s.o.
- Kernel: compartido entre todos los contenedores
- Usan menos recursos, no están levantando una copia entera de Linux o Windoes, solo levanta el proceso de tu aplicación, con las librerías que necesita, nada más
- DOCKER: podemos empaquetar esos contenedores y compartirlos de forma fácil y segura entre máquinas. Lo bueno es que podemos desarrollar todo en nuestro PC, empaquetarlo y pasarlo a un servidor. La aplicación va a correr exactamente igual porque todas las dependencias están dentro del contenedor
- MAGIA DE DOCKER: permite que un desarrollador pueda crear un entorno local, y se asegura que ese entorno va a funcionar exactamente igual que un servidor. Así no pasará nunca que algo funcione en mi máquina y no en un servidor.

* VM (una computadora dentro de otra): la usamos cuando queremos una aplicación que si o sí necesita de todos los recursos de la máquina; aplicaciones muy pesadas o que no se manejan bien con porciones de hardware
* CONTENEDORES (como un pequeño directorio): mejores si queremos aprovechar al máximo los recursos que tenemos en un hardware

- Una **imagen** es una versión de un contenedor. Así siempre puedo volver a una versión anterior.
  Una imagen es una plantilla de solo lectura con instrucciones para crear un contenedor. Normalmente, una imagen se basa en otra imagen, con alguna customización adicional.

- Un contenedor es una instancia ejecutable de una imagen.

- **dockerfile**
    - Es un conjunto de instrucciones que sirve para crear imágenes. Siempre se inicia con una línea que dice FROM que indica que este contenedor que estoy creando se basa en otra imagen.
    - No soporta interacción, tiene que correr sin interacción humana (-y: hace que se instalen las cosas sin preguntar, es como decirle _yes_)
    - Hay que construir el contenedor (docker build)
    
- **docker run** ejecuta un contenedor nuevo
- **docker exec** ejecuta un comando dentro de un contenedor que ya está corriendo
-**it** para que sea interactivo y cree una terminal. Quiero ejecutar un comando y quedarme dentro de esa terminal

- Docker es un motor que permite "correr" múltiples contenedores compartiendo un montón de recursos unos con otros, pero al mismo tiempo garantiza aislamiento

- Cómo funciona docker:
    - Si ejecuto **docker run ubuntu**, lo que hace es ejecutar y nada más. Docker está configurado para correr un solo proceso.
    - Es decir: docker run one process --> process exits --> docker exists
    - Para  que se interactivo y abra terminal tenemos que ejecutar **docker run -it ubuntu**
    - La única manera de contactar con un contenedor es a través de networking. Para ello necesitas puertos abiertos, así tú puedes enviar tráfico a ese puerto particular y recibir la respuesta desde un puerto abierto
- Para configurar docker (best practices):
      + **NO**: crear una imagen, y si tenemos un nginx y queremos crear un virtual host, podemos modificar el archivo de configuración y después crear la imagen con el archivo de configuración modificado (no buena idea)
      + **SI**: descargar una imagen con todo configurado y le pasas por variables de entorno la configuración que necesitas
  
  - **docker run -e MYSQL_ROOT_PASSWORD=miclave -d mysql:8.0.13**
      + **-e** configura variables de entorno
      + **-d** corre el contenedor en segundo plano e imprime el container ID
      El contenedor de MYSQL ya tiene script dentro que corre dentro de ese contenedor cuando se inicia; lee las variables de entorno y se fija si existe esa variable de entorno (MYSQL_ROOT_PASSWORD). Si la encuentra la configura
      Así se configuran los contenedores --> fuera del contenedor. Pasando la configuración con variables de entorno y así lo puedo compartir con cualquier persona y que él configure lo que necesite, bajando esa imagen
      Puedo agregar más variables de entorno

# DEBIAN BUSTER
- ¿Qué es Debian?
    + El Proyecto Debian es una asociación de personas que han hecho causa común para crear un sistema operativo (SO) libre. Este sistema operativo que han creado se llama Debian
    + Buster es la versión 10 de Debian
- Es la imagen (versión) sobre la que nos vamos a basar para crear nuestro contenedor

Un sistema operativo es un conjunto de programas y utilidades básicas que hacen que su computadora funcione. El centro de un sistema operativo es el núcleo (N. del T.: kernel). El núcleo es el programa más importante en la computadora, realiza todo el trabajo básico y le permite ejecutar otros programas.
    
#  NGINX
- Es un servidor web
- Está diseñado para ofrecer un bajo uso de memoria y alta ocurrencia. En lugar de  crear nuevos procesos para cada solicitud web, usa un enfoque asincrónico basado en eventos donde las solicitudes se manejan en un solo hilo. También actúa como proxy de correo electrónico, proxy inverso y balanceador de carga
- Para instalar nginx: **apt-get install nginx** (ubuntu o debian, para  otras distribuciones, buscar documentación)
- Una vez instalado hay que configurarl para que muestre nuestro sitio
- Normalmente en ubuntu tenemos todos los archivos de configuración en **/etc**
- cd/etc/nginx es un directorio que suele crearse
Hay dos archivos:
    + sites-available: aprovisionamiento, todo lo que hay aquí es lo que voy a poder ver
    + sites-enabled: aquí se activa todo lo que quiero ver de lo disponible en sites-available. Puedo enlazar con los archivos en sites-available simplemente copiándolo aquí o haciendo un link simbólico
- **Link simbólico** es como un puntero a un archivo que está en otro lado --> ln -s ../--- .
    
# PHP (lenguaje de programación, interfaz gráfica)
- **php-fpm**: servicio que se encarga de interpretar el código de PHP
- Hay que instalar php-fpm y compilarlo para que se convierta en una página web, para que lo pueda leer nginx
- Antes de instalar paquetes, debemos hacer **apt-get update**, esto sincroniza la lista de paquetes y nos asegura que siempre tengamos la última versión de esos paquetes cuando los vamos a descargar.
- Para instalar php-fpm: **apt-get install php-fpm**
- Hay que configurar nuestro virtual host para que use php. Podemos hacerlo mediante sockets o tcp. Dependiendo de tu servicio de php-fpm tendremos habilitado o no el puerto tcp. Por defecto en ubuntu, php no usa el puerto tcp; no inicia ese servicio

# PHPMyAdmin
- phpMyAdmin es una herramienta escrita en PHP con la intención de manejar la administración de MySQL a través de páginas web, utilizando un navegador web
- Actualmente puede crear y eliminar Bases de Datos, crear, eliminar y alterar tablas, borrar, editar y añadir campos, ejecutar cualquier sentencia SQL, administrar claves en campos, administrar privilegios, exportar datos en varios formatos y está disponible en 72 idiomas
- Obviamente, no sería muy normal instalar PhpMyAdmin si no tienes una base de datos MySQL en tu sistema, o bien la base de datos MariaDB, que debes saber que es compatible con MySQL. Si tienes ya instalado MySQL / MariaDB en tu sistema, podrías ahorrarte este paso, sólo necesitarías recordar tu clave de root.
- Para instalarlo: **apt -y install php-mysql**
- El proceso de instalación te solicitará la entrada de una clave para el usuario root de MySQL, que le puedes indicar la que quieras. Los usuarios de Ubuntu 18.04 deben de saber que durante la instalación de MySQL ya no pide la clave que se va a configurar para el usuario root. Simplemente se instalará la clave vacía, o sea, el usuario root permitirá el acceso sin clave
- Mantener el servidor MySQL arrancado con: **service mysql start**
- Instalar PhpMyAdmi, con el siguiente comando: **apt-get install phpmyadmin php-mbstring php-gettext**
Además del propio PhpMyAdmin estamos instalando un par de extensiones de PHP que son requisito de PhpMyAdmin. Es habitual que estas extensiones ya estén configuradas en tu instalación de PHP, pero nunca está de más indicarlas en la instalación, por si acaso
- Cuando se está instalando PhpMyAdmin nos solicita algunas informaciones extra de configuración, en una especie de asistente de línea de comandos

# WORDPRESS
- WordPress es una plataforma de código abierto que funciona para crear cualquier tipo de sitio web, desde un blog sencillo hasta una tienda virtual o un portal de miembros
- Es un sistema de gestión de contenidos
- El proceso de instalación es muy sencillo
    + En primer lugar deberemos disponer de un lugar donde instalar nuestro WordPress. Podemos hacerlo en nuestro equipo local, si en él tenemos instalado un servidor web (por ejemplo, Apache) o hacerlo en un servicio de hosting. Solo con esta última opción podremos hacer que la web sea visible para otros usuarios. El servidor donde alojemos la web tiene que ser capaz de ejecutar **PHP** y soportar bases de datos **MySQL**. Además, existen otros requisitos mínimos que habrá que cumplir para que todo funcione correctamente.
    + Una vez que dispongamos de un lugar donde alojar nuestro WordPress, deberemos descargar el instalador de WordPress y descomprimirlo en la ruta donde se vaya a cargar la web. A continuación tendremos que crear una base de datos MySQL y un usuario con acceso a esa base de datos.
    + Ahora deberemos abrir la página donde hemos subido los archivos de WordPress. Se mostrará un asistente de instalación en varios pasos, donde tendremos que introducir los datos de conexión a la base de datos, el nombre de nuestra web, y los datos del usuario administrador. Concluido este asistente tendremos la web lista para empezar a añadir contenidos y personalizarla

# Comandos útiles
**docker ps** para ver el estado
**docker image rm $[docker image ls]** te borra todas las imágenes
**docker ps -a** para ver todos aunque estén parados
**docker run --rm** para que cuando pare borre todo para que no ocupe
**docker stats** estadísticas de tu docker corriendo
**docker system prune** todo lo levantado que no estés usando, se libera el espacio
**docker inspect <id/nombre>** trae toda la información del contenedor
**docker cp** copiar archivos a un contenedor que está corriendo y viceversa
**docker add** distinto que el anterior, porque **add** te permite usar urls, pero te descomprime directamente
**docker logs --tail=10 id** muestra las últimas 10 líneas del log de ese contenedor
**docker logs --tail=10 -t id** te da el timestamp de las líneas
**docker run -it --entrypoint=bash** a veces un contenedor falla por algún error (por ejemplo con nginx), va a reemplazar el entrypoint y así podemos levantar el contenedor con bash, y ver el error. Luego después de corregirlo, parar y volver a levantar después con nginx
    
# NOTAS
- **alpine** versión de linux∫
- **ubuntu** sistema operativo basado en linux
- **servidor web** es un proceso, un servicio que corre y expone el puerto, generalmente el puerto 80 y el 443 (los más usados para las páginas web), que te permite poner código (por ejemplo html) en un directorio y lo que hacemos es configurar el servidor web para que te muestre ese código cuando navegas con un navegador. Por defecto los servidores web solo interpretan el lenguaje html. Otros lenguajes necesitarán un plug-in, un programa extra que enseñe a nginx cómo interpretar esos archivos
- **Virtual host** es una de las modalidades más utilizadas por las empresas dedicadas al negocio del alojamiento web. Dependiendo de los recursos disponibles, permite tener una cantidad variable de dominios y sitios web en una misma máquina.
    Este concepto emula, en nuestro servidor local, el efecto de un servidor remoto, incluyendo el uso de una URL personalizada, que podemos elegir a nuestra conveniencia, para cada proyecto, ya que podemos crear en nuestro equipo tantos servidores virtuales cómo necesitemos
- **dirección ip** es como la matrícula de un coche, o el DNI. Es un código que va a identificar a cada usuario que está navegando por cualquier red, y es la forma que tiene internet de saber quién es quién, ya sea un dominio o un equipo. Un dispositivo no va a poder establecer comunicaciones con nadie si no tiene una de estas direcciones
-**HOST** o anfitrión es un ordenador que funciona como el puerto de inicio y final de las transferencias de datos. Más comúnmente descrito como el lugar donde reside un sitio web.
Un host de internet tiene una **dirección de internet** única (**dirección ip**) y un **nombre de dominio** único o nombre de host. 
Host también se usa para referirse a una compañía que ofrece servicios de alojamiento para sitios web
